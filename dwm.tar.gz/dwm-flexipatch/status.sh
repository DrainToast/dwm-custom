#!/bin/bash
# ~/.dwm/status2d.sh
# Status2D-compatible status for dwm
# CPU, RAM, GPU, Network, Time with adjustable heatmap colors and padding

BG="#3c3836"   # uniform background
FG="#ebdbb2"
PAD=3          # number of spaces between sections

# Heatmap color constants (adjust to your preference)
COLOR_LOW="#b8bb26"    # green at 0%
COLOR_MID="#fabd2f"    # yellow at 50%
COLOR_HIGH="#fb4934"   # red at 100%

NETIF=$(ip route get 8.8.8.8 | awk '{for(i=1;i<=NF;i++){if($i=="dev"){print $(i+1)}}}')
RX_PREV=$(cat /sys/class/net/$NETIF/statistics/rx_bytes)
TX_PREV=$(cat /sys/class/net/$NETIF/statistics/tx_bytes)

# Convert hex color to RGB components
hex_to_rgb() {
    local hex=$1
    printf "%d %d %d" $((16#${hex:1:2})) $((16#${hex:3:2})) $((16#${hex:5:2}))
}

# Convert RGB components to hex string
rgb_to_hex() {
    printf "#%02x%02x%02x" $1 $2 $3
}

# Linear interpolation between two values
lerp() {
    local start=$1
    local end=$2
    local t=$3
    echo $(( start + (end - start) * t / 100 ))
}

# Smooth heatmap: interpolate low->mid->high
heat_color() {
    local P=$1
    local R G B
    # Split gradient into 0-50 and 51-100
    if [ $P -le 50 ]; then
        t=$(( P * 2 )) # scale 0-50 -> 0-100
        read R1 G1 B1 <<< $(hex_to_rgb "$COLOR_LOW")
        read R2 G2 B2 <<< $(hex_to_rgb "$COLOR_MID")
    else
        t=$(( (P-50)*2 )) # scale 51-100 -> 0-100
        read R1 G1 B1 <<< $(hex_to_rgb "$COLOR_MID")
        read R2 G2 B2 <<< $(hex_to_rgb "$COLOR_HIGH")
    fi
    R=$(lerp $R1 $R2 $t)
    G=$(lerp $G1 $G2 $t)
    B=$(lerp $B1 $B2 $t)
    rgb_to_hex $R $G $B
}

# Generate padding string
pad() {
    local count=$1
    local s=""
    for ((i=0;i<count;i++)); do s+=" "; done
    echo "$s"
}

PAD_STR=$(pad $PAD)

while true; do
    # --- CPU ---
    CPU=$(awk 'NR==1{idle=$5; total=$2+$3+$4+$5+$6+$7+$8; printf "%.0f", (total-idle)*100/total}' /proc/stat)
    CPU_COLOR=$(heat_color $CPU)

    # --- RAM ---
    MEM_USED=$(free -b | awk '/Mem:/ {print $3}')
    MEM_TOTAL=$(free -b | awk '/Mem:/ {print $2}')
    MEM_PERCENT=$(( MEM_USED * 100 / MEM_TOTAL ))
    MEM=$(printf "%.1fG/%.1fG" $(echo "$MEM_USED/1024/1024/1024" | bc -l) $(echo "$MEM_TOTAL/1024/1024/1024" | bc -l))
    MEM_COLOR=$(heat_color $MEM_PERCENT)

    # --- GPU ---
    if command -v nvidia-smi &> /dev/null; then
        GPU_VAL=$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits)
        GPU="${GPU_VAL}%"
        GPU_COLOR=$(heat_color $GPU_VAL)
    else
        GPU="N/A"
        GPU_COLOR=$FG
    fi

    # --- Network ---
    RX_NOW=$(cat /sys/class/net/$NETIF/statistics/rx_bytes)
    TX_NOW=$(cat /sys/class/net/$NETIF/statistics/tx_bytes)
    RX_RATE=$(( (RX_NOW - RX_PREV)/1024 ))
    TX_RATE=$(( (TX_NOW - TX_PREV)/1024 ))
    NET="${RX_RATE}↓/${TX_RATE}↑"
    RX_PREV=$RX_NOW
    TX_PREV=$TX_NOW
    NET_COLOR=$FG

    # --- Time ---
    TIME=$(date "+%a %d %b %H:%M")
    TIME_COLOR=$FG

    # --- Build Status2D string ---
    STATUS=""
    STATUS+="^c$FG^^b$BG^${PAD_STR}CPU:^d^^c$CPU_COLOR^ $CPU%${PAD_STR}^d^"
    STATUS+="^c$FG^^b$BG^${PAD_STR}RAM:^d^^c$MEM_COLOR^ $MEM${PAD_STR}^d^"
    STATUS+="^c$FG^^b$BG^${PAD_STR}GPU:^d^^c$GPU_COLOR^ $GPU${PAD_STR}^d^"
    STATUS+="^c$NET_COLOR^^b$BG^${PAD_STR}NET: $NET${PAD_STR}^d^"
    STATUS+="^c$TIME_COLOR^^b$BG^${PAD_STR}$TIME${PAD_STR}^d^"

    xsetroot -name "$STATUS"
    sleep 1
done
