#include <X11/XF86keysym.h>

/* appearance */
static const unsigned int borderpx = 2;
static const unsigned int snap = 32;
static const int showbar = 1;
static const int topbar = 1;

/* fonts */
static const char *fonts[] = { "monospace:size=10" };


#define SchemeTagsNorm SchemeNorm
#define SchemeTagsSel  SchemeSel
#define SchemeTagsUrg  SchemeUrg


//* Normal (unfocused windows) */
static char normfgcolor[]       = "#ebdbb2";
static char normbgcolor[]       = "#282828";
static char normbordercolor[]   = "#282828";
static char normfloatcolor[]    = "#282828";

/* Selected (focused windows) */
static char selfgcolor[]        = "#ebdbb2";
static char selbgcolor[]        = "#928374";
static char selbordercolor[]    = "#98971a";
static char selfloatcolor[]     = "#98971a";

// Urgent
static char urgfgcolor[]      = "#cc241d";
static char urgbgcolor[]      = "#282828";
static char urgbordercolor[]  = "#cc241d";
static char urgfloatcolor[]   = "#cc241d";




static char *colors[][ColCount] = {
	/*                       fg                bg                border                float */
	[SchemeNorm]         = { normfgcolor,      normbgcolor,      normbordercolor,      normfloatcolor },
	[SchemeSel]          = { selfgcolor,       selbgcolor,       selbordercolor,       selfloatcolor },
    [SchemeUrg]          = { urgfgcolor,       urgbgcolor,       urgbordercolor,       urgfloatcolor },

};


static const unsigned int gappih = 10;  /* horizontal inner gap between windows */
static const unsigned int gappiv = 10;  /* vertical inner gap between windows */
static const unsigned int gappoh = 10;  /* horizontal outer gap between windows and screen edge */
static const unsigned int gappov = 10;  /* vertical outer gap between windows and screen edge */
static int smartgaps_fact = 1;

static const int refreshrate = 120;  /* refresh rate (per second) for client move/resize */

static const int swallowfloating = 1;

// dmenu stuff (required but not used)
static const char dmenufont[] = "monospace:size=10";
static char dmenumon[2] = "";
static const char *dmenucmd[] = {NULL};





// Commands
static const char *launcher[] = { "rofi", "-show", "drun", "-show-icons", NULL };
static const char *powermenu[] = {
  "sh", "-c",
  "chosen=$(echo -e ' Shutdown\\n Reboot\\n Lock\\n Logout\\n Suspend' | rofi -dmenu -i -p 'Power' -width 20) && " \
  "case \"$chosen\" in " \
  "' Shutdown') systemctl poweroff ;; " \
  "' Reboot') systemctl reboot ;; " \
  "' Lock') loginctl lock-session ;; " \
  "' Logout') pkill -KILL -u $USER ;; " \
  "' Suspend') systemctl suspend ;; " \
  "esac",
  NULL
};
static const char *termcmd[]  = { "alacritty", NULL };


static const int tagindicatortype              = INDICATOR_CLIENT_DOTS;
static const int tiledindicatortype            = INDICATOR_NONE;
static const int floatindicatortype            = INDICATOR_CLIENT_DOTS;


/* tags */
#define NUMTAGS 9
static char *tagicons[][NUMTAGS] = {
  [0] = { "1","2","3","4","5","6","7","8","9" },
};

/* rules */
static const Rule rules[] = {
  { NULL, NULL, NULL, NULL, 0, 0, -1 },
};

static const int bar_height = 24;  // pixels

static const BarRule barrules[] = {
	/* monitor   bar    alignment         widthfunc                 drawfunc                clickfunc                hoverfunc                name */
	{ -1,        0,     BAR_ALIGN_LEFT,   width_tags,               draw_tags,              NULL,                    NULL,                  "tags" },
    { -1,        0,     BAR_ALIGN_LEFT,   width_ltsymbol,           draw_ltsymbol,          click_ltsymbol,          NULL,                  "layout" },
    { -1,        0,     BAR_ALIGN_RIGHT,  width_status2d,           draw_status2d,          NULL,                    NULL,                  "status" },
};


/* layouts */
static const float mfact = 0.42;
static const int nmaster = 1;
static const int resizehints = 0;
static const int lockfullscreen = 1;

static const Layout layouts[] = {
  /* symbol     arrange function */
  { "[]=",      tile },
  { "><>",      NULL },
  { "[M]",      monocle },
  { "TTT",      bstack },
  { "[D]",      deck },
  { "###",      grid },
};



/* key definitions */
#define MODKEY Mod4Mask
#define TAGKEYS(KEY,TAG) \
  { MODKEY,                       KEY,      comboview,           {.ui = 1 << TAG} }, \
  { MODKEY|ShiftMask,             KEY,      combotag,            {.ui = 1 << TAG} }, \
  { MODKEY|ControlMask,           KEY,      toggleview,     {.ui = 1 << TAG} }, \
  { MODKEY|ShiftMask|ControlMask, KEY,      toggletag,      {.ui = 1 << TAG} }




static const Key keys[] = {
  // Spawn
  { MODKEY, XK_Return, spawn, {.v = termcmd } },
  { MODKEY, XK_space, spawn, {.v = launcher } },

  { MODKEY|ShiftMask, XK_p, spawn, {.v = powermenu } },


    /* Window management */
    // Focus windows
    { MODKEY,           XK_h,  focusdir, {.i = 0} }, // left
    { MODKEY,           XK_l,  focusdir, {.i = 1} }, // right
    { MODKEY,           XK_k,  focusdir, {.i = 2} }, // up
    { MODKEY,           XK_j,  focusdir, {.i = 3} }, // down
    // Move windows
    { MODKEY|ShiftMask, XK_h,  placedir, {.i = 0} }, // left
    { MODKEY|ShiftMask, XK_l,  placedir, {.i = 1} }, // right
    { MODKEY|ShiftMask, XK_k,  placedir, {.i = 2} }, // up
    { MODKEY|ShiftMask, XK_j,  placedir, {.i = 3} }, // down

    { MODKEY|ShiftMask,             XK_space,  setlayout, {0} },
    { MODKEY,                       XK_f,      togglefullscreen,  {0} },
    { MODKEY, XK_q, killclient, {0} },
    { MODKEY|ShiftMask, XK_q, quit, {0} },

    /* Tags */
    TAGKEYS(                        XK_1,                      0),
    TAGKEYS(                        XK_2,                      1),
    TAGKEYS(                        XK_3,                      2),
    TAGKEYS(                        XK_4,                      3),
    TAGKEYS(                        XK_5,                      4),
    TAGKEYS(                        XK_6,                      5),
    TAGKEYS(                        XK_7,                      6),
    TAGKEYS(                        XK_8,                      7),
    TAGKEYS(                        XK_9,                      8),
};
/* mouse buttons */
static const Button buttons[] = {
  { ClkClientWin, MODKEY, Button1, movemouse, {0} },
  { ClkClientWin, MODKEY, Button3, resizemouse, {0} },
};

/* AltTab patch options */
static int tabposx    = 1;       /* 0: left, 1: center, 2: right */
static int tabposy    = 1;       /* 0: top, 1: center, 2: bottom */
static unsigned int maxwtab = 500; /* max width of alttab window */
static unsigned int maxhtab = 200; /* max height of alttab window */
static KeySym tabmodkey = XK_Alt_L; /* mod key for alttab (usually Alt) */
static KeySym tabcyclekey = XK_Tab; /* key to cycle windows in alttab */


/* autostart commands */
static const char *const autostart[] = {
    "~/dwm-flexipatch/status.sh", NULL,
    "picom", "--experimental-backends", NULL,   // compositor
    NULL                                        // always end with NULL
};
