static void setborderpx(const Arg *arg);

