static int width_taggrid(Bar *bar, BarArg *a);
static int draw_taggrid(Bar *bar, BarArg *a);
static int click_taggrid(Bar *bar, Arg *arg, BarArg *a);
static void switchtag(const Arg *arg);

