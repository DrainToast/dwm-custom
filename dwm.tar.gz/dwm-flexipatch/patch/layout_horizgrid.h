static void horizgrid(Monitor *m);

