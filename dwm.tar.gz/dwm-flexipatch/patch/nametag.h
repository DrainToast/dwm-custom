static void nametag(const Arg *arg);
