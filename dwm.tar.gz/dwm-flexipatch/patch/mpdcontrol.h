static void mpdchange(const Arg *direction);
static void mpdcontrol();

