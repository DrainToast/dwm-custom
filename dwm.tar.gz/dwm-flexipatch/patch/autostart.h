static void runautostart(void);

