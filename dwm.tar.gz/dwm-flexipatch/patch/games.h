static void minimize(Client *c);
static void unminimize(Client *c);
