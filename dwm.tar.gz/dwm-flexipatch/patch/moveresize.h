static void moveresize(const Arg *arg);

