static void tagallmon(const Arg *arg);

